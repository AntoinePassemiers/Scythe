#include "RcppArmadillo.h"
// [[Rcpp::depends(RcppArmadillo)]]


// [[Rcpp::export]]
double foo() {
	double a;
	std::cout << "Hello Sakuya !" << std::endl;
	return a;
}
